# SMLHelper Experimental
SMLHelper is a modding library that helps making mods easier by helping with adding new items, changing items, adding models, sprites, etc.
This copy of SMLHelper is made for the Experimental Steam Branch and may break often as the Experimental branch gets updated. EXPECT BUGS!
Check out [the wiki page](https://github.com/SubnauticaModding/SMLHelper/wiki) for details on how to use it.


